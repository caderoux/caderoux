﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DemoApp
{
    class Program
    {
        static void Main(string[] args)
        {
            DumpLookups.DumpAll();
        }
    }
}
